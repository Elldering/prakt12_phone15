package com.example.prakt12_java;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.os.Bundle;
import android.widget.Toast;

public class menu extends AppCompatActivity {

    private EditText editTextYourName;
    private EditText editTextOpponentName;
    private Button startButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        editTextYourName = findViewById(R.id.editTextYourName);
        editTextOpponentName = findViewById(R.id.editTextOpponentName);
        startButton = findViewById(R.id.startGame);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String yourName = editTextYourName.getText().toString();
                String opponentName = editTextOpponentName.getText().toString();

                if (yourName.isEmpty() || opponentName.isEmpty()) {

                    Toast.makeText(menu.this, "Заполните оба поля с именами", Toast.LENGTH_SHORT).show();
                } else {

                    if (opponentName.toLowerCase().contains("бот")) {
                        Intent intent = new Intent(menu.this, MainActivity.class);
                        intent.putExtra("yourName", yourName);
                        intent.putExtra("opponentName", opponentName);
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(menu.this, MainActivity2.class);
                        intent.putExtra("yourName", yourName);
                        intent.putExtra("opponentName", opponentName);
                        startActivity(intent);
                    }
                }
            }
        });
    }
}