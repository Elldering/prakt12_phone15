package com.example.prakt12_java;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {
    boolean isPlayer1Turn = true;

    Button[] buttons = new Button[9];
    TextView textView, humanPoints, PcPoints;
    ImageButton img_btn;
    String krest = "x", nol = "0";
    int pointOfHuman, pointOfPc;

    SharedPreferences settings;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        settings = getSharedPreferences("SETTINGS", MODE_PRIVATE);
        if(settings.contains("MODE_NIGHT_ON")){
            setCurrentTheme();
        }
        else{
            editor = settings.edit();
            editor.putBoolean("MODE_NIGHT_ON", false);
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            Toast.makeText(this, "День", Toast.LENGTH_SHORT).show();
        }

        setContentView(R.layout.activity_main);

        initView();
        loadGameState();
    }
    private void setCurrentTheme() {
        if(settings.getBoolean("MODE_NIGHT_ON", false)){
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }
        else{
            AppCompatDelegate.setDefaultNightMode((AppCompatDelegate.MODE_NIGHT_NO));
        }
    }
    private void initView() {
        textView = findViewById(R.id.textView);
        humanPoints = findViewById(R.id.humanPoints);
        PcPoints = findViewById(R.id.PcPoints);
        img_btn = findViewById(R.id.image_btn);

        img_btn.setImageResource(settings.getBoolean("MODE_NIGHT_ON", false) ? R.drawable.its_sun : R.drawable.its_moon);

        img_btn.setOnClickListener(view -> {
            SharedPreferences.Editor editor = settings.edit();
            editor.putBoolean("MODE_NIGHT_ON", !settings.getBoolean("MODE_NIGHT_ON", false));
            editor.apply();
            Intent intent = getIntent();
            intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            finish();
            startActivity(intent);
        });

        for (int i = 0; i < buttons.length; i++) {
            String buttonId = "button" + (i + 1);
            int resourceId = getResources().getIdentifier(buttonId, "id", getPackageName());
            buttons[i] = findViewById(resourceId);
            buttons[i].setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View view) {
        Button button = (Button) view;
        if (button.getText().toString().isEmpty()) {
            if (isPlayer1Turn) {
                button.setText(krest);
            } else {
                button.setText(nol);
            }
            isPlayerWinner();
            isPlayer1Turn = !isPlayer1Turn;
        }
    }


    private void isPlayerWinner() {
        String currentPlayerSymbol = isPlayer1Turn ? krest : nol;
        if (WinMB(currentPlayerSymbol)) {
            String winnerName = isPlayer1Turn ? "Игрок 1" : "Игрок 2";
            textView.setText(winnerName + " выиграл!");
            if (isPlayer1Turn) {
                pointOfHuman++;
            } else {
                pointOfPc++;
            }
            UpdateWins("winner");
            disableAllButtons();
        } else {
            if (isBoardFull()) {
                textView.setText("Ничья!");
                disableAllButtons();
            }
        }
    }
    private void disableAllButtons() {
        for (Button button : buttons) {
            button.setEnabled(false);
        }
    }
    private boolean isBoardFull() {
        for (Button button : buttons) {
            if (button.getText().toString().isEmpty()) {
                return false;
            }
        }
        return true;
    }


    private void hodPC() {
        Random random = new Random();
        int buttonPcClick;
        do {
            buttonPcClick = random.nextInt(9);
        } while (!buttons[buttonPcClick].getText().toString().isEmpty());

        buttons[buttonPcClick].setText(nol);
        isPCWinner();
    }

    private void isPCWinner() {
        if (WinMB(nol)) {
            textView.setText(R.string.PC_winner_mesenge);
            pointOfPc++;
            UpdateWins("bot");
        }
    }

    private void UpdateWins(String check) {
        if (check.equals("winner")) {
            humanPoints.setText(String.valueOf(pointOfHuman));
        } else {
            PcPoints.setText(String.valueOf(pointOfPc));
        }
        saveGameState();
    }

    private void saveGameState() {
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("pointOfHuman", pointOfHuman);
        editor.putInt("pointOfPc", pointOfPc);
        editor.apply();
    }

    private void loadGameState() {
        pointOfHuman = settings.getInt("pointOfHuman", 0);
        pointOfPc = settings.getInt("pointOfPc", 0);
        humanPoints.setText(String.valueOf(pointOfHuman));
        PcPoints.setText(String.valueOf(pointOfPc));
    }

    public void clcRestart(View view) {
        for (Button button : buttons) {
            button.setText("");
        }
    }
    private boolean WinMB(String symbol) {

        for (int i = 0; i < 3; i++) {
            if (buttons[i].getText().toString().equals(symbol)
                    && buttons[i + 3].getText().toString().equals(symbol)
                    && buttons[i + 6].getText().toString().equals(symbol)) {
                return true;
            }
        }

        for (int i = 0; i < 9; i += 3) {
            if (buttons[i].getText().toString().equals(symbol)
                    && buttons[i + 1].getText().toString().equals(symbol)
                    && buttons[i + 2].getText().toString().equals(symbol)) {
                return true;
            }
        }

        if (buttons[0].getText().toString().equals(symbol)
                && buttons[4].getText().toString().equals(symbol)
                && buttons[8].getText().toString().equals(symbol)) {
            return true;
        }
        if (buttons[2].getText().toString().equals(symbol)
                && buttons[4].getText().toString().equals(symbol)
                && buttons[6].getText().toString().equals(symbol)) {
            return true;
        }

        return false;
    }
}
